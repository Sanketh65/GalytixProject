using Microsoft.AspNetCore.Mvc;
using YourWebApiProject.Models;
using System.Collections.Generic;

namespace YourWebApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CountryGwpController : ControllerBase
    {
        [HttpPost("avg")]
        public IActionResult CalculateAverageGwp([FromBody] CountryGwpRequest request)
        {
            // Your logic to read gwpByCountry.csv and calculate GWP averages here

            // Simulated output data
            var result = new Dictionary<string, double>
            {
                { "transport", 446001906.1 },
                { "liability", 634545022.9 }
            };

            return Ok(result);
        }
    }
}
